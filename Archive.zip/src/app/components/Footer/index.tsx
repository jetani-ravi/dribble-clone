import * as React from 'react';
export function Footer() {
  return (
    <>
     
    </>
  );
}
